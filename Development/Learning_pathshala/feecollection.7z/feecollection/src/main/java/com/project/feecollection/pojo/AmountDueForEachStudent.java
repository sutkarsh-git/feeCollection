package com.project.feecollection.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AmountDueForEachStudent {
	
	Integer year;
	Integer studentId;
	Double amountDue;
	Double amountPaid;
	
	public AmountDueForEachStudent(Integer year, Integer studentId, Double amountDue, Double amountPaid) {
		super();
		this.year = year;
		this.studentId = studentId;
		this.amountDue = amountDue;
		this.amountPaid = amountPaid;
	}
	
	

}
