package com.project.feecollection.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.feecollection.exceptions.EmptyInputException;
import com.project.feecollection.model.Fees;
import com.project.feecollection.pojo.AmountDueForEachStudent;
import com.project.feecollection.repository.FeesRepository;

@Service
public class FeesService {

	private final FeesRepository feesRepository;

	@Autowired
	public FeesService(FeesRepository feesRepository) {
		super();
		this.feesRepository = feesRepository;
	}

	public List<Fees> getFeesByStudentId(Integer studentId) {
		// TODO Auto-generated method stub
		return feesRepository.findFeesByStudentId(studentId);
	}

	public Fees getFeesByStudentIdAndMonthAndYear(Integer studentId, String month, Integer year) {
		// TODO Auto-generated method stub
		return feesRepository.findFeesByStudentIdAndMonthAndYear(studentId, month, year);
	}

	public List<AmountDueForEachStudent> getAmountDueForEachStudentYear(Integer studentId, Integer year) {
		// TODO Auto-generated method stub
		return feesRepository.findAmountDueForEachStudentYear(studentId, year);
	}

	public void addNewFees(Fees fees) {

		if (fees != null && fees.getStudentId() == null || fees.getStudentId() == 0) {
			throw new EmptyInputException("601", "First Name cannot be empty");
		}

		feesRepository.save(fees);

	}

	/*
	 * public Student getStudentByEmail(String email) { // TODO Auto-generated
	 * method stub return feesRepository.findStudentByEmail(email); }
	 * 
	 * public Student getStudentByPhone(String phoneNo) { // TODO Auto-generated
	 * method stub return feesRepository.findStudentByPhoneNo(phoneNo); }
	 * 
	 * public Student getStudentByfNameAndlName(String fname, String lname) { //
	 * TODO Auto-generated method stub return
	 * feesRepository.findStudentByFirstNameAndLastName(fname, lname); }
	 * 
	 * public List<Student> getAllStudentsByGrade(Integer grade) { // TODO
	 * Auto-generated method stub return feesRepository.findStudentByGrade(grade); }
	 * 
	 * public void addNewStudent(Student student) {
	 * 
	 * // if the email is already taken , return an exception instead of inserting
	 * the // student in db
	 * 
	 * if (student != null && student.getFirstName() == null ||
	 * student.getFirstName().length() <= 0) { throw new EmptyInputException("601",
	 * "First Name cannot be empty"); }
	 * 
	 * if (feesRepository.existsByEmail(student.getEmail())) { throw new
	 * EmailAlreadyRegisteredException("602", "Email is already taken"); }
	 * feesRepository.save(student);
	 * 
	 * }
	 */

}
