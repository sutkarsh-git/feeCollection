package com.project.feecollection.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ChangePasswordDTO {
	
	private String token;
	private String password;
	
	
	public ChangePasswordDTO(String token, String password) {
		super();
		this.token = token;
		this.password = password;
	}


	

}
