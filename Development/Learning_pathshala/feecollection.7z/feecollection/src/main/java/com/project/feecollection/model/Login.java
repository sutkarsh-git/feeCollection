package com.project.feecollection.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Login {
	
	private String email;
	private String password;
	private String userRole;
	
	
	public Login(String email, String password, String userRole) {
		super();
		this.email = email;
		this.password = password;
		this.userRole = userRole;
	}

	
	
}
