package com.project.feecollection.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.feecollection.model.User;
import com.project.feecollection.model.UserRole;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{
	
	User findByEmail(String email);
	
	User findUserByEmailAndPasswordAndUserRole(String email, String password,UserRole userRole );
	
	User findUserByPhoneNo(String phoneNumber);
	
//	User findUserByFirstNameAndLastName(String firstName, String lastName);
	
	List<User> findByUserRole(UserRole userRole);
	
	Boolean existsByEmail(String email);
	
	Boolean existsByEmailAndPassword(String email, String password);
	
	User findByResetPasswordToken(String token);


}
