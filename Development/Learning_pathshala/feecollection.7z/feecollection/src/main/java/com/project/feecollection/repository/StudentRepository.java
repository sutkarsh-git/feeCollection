package com.project.feecollection.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.feecollection.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	
	Student findStudentByEmail(String email);
	
	Student findStudentByPhoneNo(String phoneNumber);
	
	List<Student> findStudentByGrade(Integer grade);
	
	Boolean existsByEmail(String email);

}
