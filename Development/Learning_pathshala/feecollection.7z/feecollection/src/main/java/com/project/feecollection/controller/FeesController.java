package com.project.feecollection.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.feecollection.model.Fees;
import com.project.feecollection.pojo.AmountDueForEachStudent;
import com.project.feecollection.service.FeesService;

@RestController
public class FeesController {

	private final FeesService feesService;

	@Autowired
	public FeesController(FeesService feesService) {
		super();
		this.feesService = feesService;
	}

	@GetMapping("/fees/{studentId}")
	public List<Fees> getFeesByStudentId(@PathVariable("studentId") Integer studentId) {
		return feesService.getFeesByStudentId(studentId);

	}

	@GetMapping("/fees/studentId/{studentId}/month/{month}/year/{year}")
	public Fees getFeesByStudentIdAndMonthAndYear(@PathVariable("studentId") Integer studentId,
			@PathVariable("month") String month, @PathVariable("year") Integer year) {
		return feesService.getFeesByStudentIdAndMonthAndYear(studentId, month, year);

	}

	@GetMapping("/fees/studentId/{studentId}/year/{year}")
	public List<AmountDueForEachStudent> getFeesByStudentIdAndMonthAndYear(@PathVariable("studentId") Integer studentId,
			@PathVariable("year") Integer year) {

		System.out
				.println("-----------------------------" + feesService.getAmountDueForEachStudentYear(studentId, year));
		return feesService.getAmountDueForEachStudentYear(studentId, year);

	}

	@PostMapping("/fees")
	public void createFees(@RequestBody Fees fees) {

		feesService.addNewFees(fees);

	}
	/*
	 * @GetMapping("/students/phone/{phoneNo}") public Student
	 * getStudentByPhone(@PathVariable("phoneNo") String phoneNo) { return
	 * studentService.getStudentByPhone(phoneNo);
	 * 
	 * }
	 * 
	 * @GetMapping("/students/fname/{fname}/lname/{lname}") public Student
	 * getStudentByfNameAndlName(@PathVariable("fname") String
	 * fname, @PathVariable("lname") String lname) { return
	 * studentService.getStudentByfNameAndlName(fname, lname);
	 * 
	 * }
	 * 
	 * @GetMapping("/students/grade/{grade}") public List<Student>
	 * getAllStudentsByGrade(@PathVariable("grade") Integer grade) { return
	 * studentService.getAllStudentsByGrade(grade);
	 * 
	 * }
	 * 
	 * @PostMapping("/students") public void createStudent(@RequestBody Student
	 * student) {
	 * 
	 * studentService.addNewStudent(student);
	 * 
	 * }
	 * 
	 */

}
