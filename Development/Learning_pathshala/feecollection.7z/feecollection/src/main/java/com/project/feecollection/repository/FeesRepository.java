package com.project.feecollection.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.feecollection.model.Fees;
import com.project.feecollection.pojo.AmountDueForEachStudent;

public interface FeesRepository extends JpaRepository<Fees, Long> {
	
	Fees findFeesByStudentIdAndMonthAndYear(Integer studentId, String month, Integer year);
	
	List<Fees> findFeesByStudentId(Integer studentId);
	
	
	  //@Query("SELECT year,studentId ,sum(amountDue),sum(amountPaid) FROM Fees where studentId = ?1 and year= ?2 group by year,studentId order by year asc")
	@Query("SELECT new com.project.feecollection.pojo.AmountDueForEachStudent(e.year,e.studentId ,sum(e.amountDue),sum(e.amountPaid)) " + "FROM Fees AS e where studentId = ?1 and year= ?2 group by e.year,e.studentId order by e.year asc")  
	List<AmountDueForEachStudent> findAmountDueForEachStudentYear(Integer studentId, Integer year);
	  
	  //
	 
	//totalDuebyStudent

}
