package com.project.feecollection.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.feecollection.model.Accountant;

@Repository
public interface AccountantRepository extends JpaRepository<Accountant, Integer> {

	
	  Accountant findAccountantByEmail(String email);
	  
	  Accountant findAccountantByPhoneNo(String phoneNumber);
	  
	  Boolean existsByEmail(String email);
	  
	 
}
