package com.project.feecollection.controller;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.project.feecollection.dto.ChangePasswordDTO;
import com.project.feecollection.dto.EmailDTO;
import com.project.feecollection.model.Login;
import com.project.feecollection.model.User;
import com.project.feecollection.service.UserService;
import com.project.feecollection.utils.UtilityApplicationURL;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class UserController {

	private final UserService userService;



	@GetMapping("/users")
	public List<User> getAllUsers() {
		return userService.getAllUsers();

	}

	@GetMapping("/users/{userId}")
	public Optional<User> getUserById(@PathVariable("userId") Long userId) {
		return userService.getUserById(userId);

	}

	@GetMapping("/users/email/{email}")
	public User getUserByEmail(@PathVariable("email") String email) {
		return userService.getUserByEmail(email);

	}

	@GetMapping("/users/phone/{phoneNo}")
	public User getUserByPhone(@PathVariable("phoneNo") String phoneNo) {
		return userService.getUserByPhone(phoneNo);

	}
	
	/*
	 * @GetMapping("/users/fname/{fname}/lname/{lname}") public User
	 * getUserByfNameAndlName(@PathVariable("fname") String fname
	 * , @PathVariable("lname") String lname) { return
	 * userService.getUserByfNameAndlName(fname, lname);
	 * 
	 * }
	 */
	@GetMapping("/users/userrole/{userrole}")
	public List<User> getAllUsersByUserRole(@PathVariable("userrole") String userrole ) {
		return userService.getAllUsersByUserRole(userrole);

	}


	@PostMapping("/users")
	public void createUser(@RequestBody User user) {

		userService.addNewUser(user);

	}

	@DeleteMapping("/users/{userId}")
	public void deleteUser(@PathVariable("userId") Long userId) {

		userService.deleteUser(userId);

	}

	/* seems not needed to update the user
	 * @PutMapping("/users/{userId}") public void
	 * updateStudent(@PathVariable("userId") Long userId, @RequestParam(required =
	 * false) String name,
	 * 
	 * @RequestParam(required = false) String email) {
	 * 
	 * userService.updateStudent(userId, name, email);
	 * 
	 * }
	 */
	//adding login functionality
	
	@PostMapping("/login")
	@ResponseStatus(HttpStatus.CREATED)
	public void  login(@RequestBody Login login) {
		
		userService.validateUserLogin(login);


	}
	
	//forget password functionality
	
	//take the email as input and generate a random token, if the email exists ..save the token in the db and then send an email with the token link.
	@PostMapping("/forgetpassword")
	@ResponseStatus(HttpStatus.CREATED)
	public void forgetPasswordSaveToken(HttpServletRequest request, Model model, @RequestBody EmailDTO email) {
		
		//make a random token
		String token = RandomStringUtils.randomAlphanumeric(30);
		System.out.println(token + "^^^^^^^^^^^^");
		//call service to validate the email and save the token.
		userService.updateResetPasswordToken(token, email.getEmail());
		//send email 
		
		String resetPasswordLink = UtilityApplicationURL.getSiteURL(request) + "/reset_password?token=" + token;
		userService.sendEmail(email.getEmail(), resetPasswordLink);
	}
	
	@GetMapping("/getUserByToken/{token}")
	@ResponseStatus(HttpStatus.OK)
	public User getUserfromUserToken(@PathVariable("token") String token ) {
		
		return userService.getUserfromUserToken(token);
		
	}
	
	//change password -take the new password and token or id ..update the new password ,set the token to null
	@PostMapping("/changepassword")
	@ResponseStatus(HttpStatus.CREATED)
	public void changePasswordSetTokenNull(HttpServletRequest request, Model model, @RequestBody ChangePasswordDTO changePasswordDto) {
		
		
		userService.changePasswordSetTokenNull(changePasswordDto);
		
	}

}
