package com.project.feecollection.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.feecollection.model.Student;
import com.project.feecollection.service.StudentService;

@RestController
public class StudentController {

	private final StudentService studentService;

	@Autowired
	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}

	@GetMapping("/students")
	public List<Student> getAllStudents() {
		return studentService.getAllStudents();

	}

	@GetMapping("/students/{studentId}")
	public Optional<Student> getStudentById(@PathVariable("studentId") Integer studentId) {
		return studentService.getStudentById(studentId);

	}

	@GetMapping("/students/email/{email}")
	public Student getStudentByEmail(@PathVariable("email") String email) {
		return studentService.getStudentByEmail(email);

	}

	@GetMapping("/students/phone/{phoneNo}")
	public Student getStudentByPhone(@PathVariable("phoneNo") String phoneNo) {
		return studentService.getStudentByPhone(phoneNo);

	}

	/*
	 * @GetMapping("/students/fname/{fname}/lname/{lname}") public Student
	 * getStudentByfNameAndlName(@PathVariable("fname") String
	 * fname, @PathVariable("lname") String lname) { return
	 * studentService.getStudentByfNameAndlName(fname, lname);
	 * 
	 * }
	 */

	@GetMapping("/students/grade/{grade}")
	public List<Student> getAllStudentsByGrade(@PathVariable("grade") Integer grade) {
		return studentService.getAllStudentsByGrade(grade);

	}

	@PostMapping("/students")
	public void createStudent(@RequestBody Student student) {

		studentService.addNewStudent(student);

	}

	@DeleteMapping("/students/{studentId}")
	public void deleteStudent(@PathVariable("studentId") Integer studentId) {

		studentService.deleteStudent(studentId);

	}

	@PutMapping("/students/{studentId}")
	public void updateStudent(@PathVariable("studentId") Integer studentId, @RequestParam(required = false) String name,
			@RequestParam(required = false) String email) {

		studentService.updateStudent(studentId, name, email);

	}

}

/*
 * created a student class -model created studentcontroller as API layer and get
 * mapping uri was created. create studentservice as a service layer (to keep
 * business logic) jpa pending TBD
 * 
 * 
 */
