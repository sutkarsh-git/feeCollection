package com.project.feecollection.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = false, unique = true)
	private String email;

	@Column(nullable = false)
	private String password;

	@Column(nullable = false)
	private String phoneNo;

	private UserRole userRole;

	@Column(name = "reset_password_token")
	private String resetPasswordToken;

	public User(String email, String password, String phoneNo, UserRole userRole) {
		super();
		this.email = email;
		this.password = password;
		this.phoneNo = phoneNo;
		this.userRole = userRole;
	}

}
