package com.project.feecollection.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.feecollection.exceptions.EmailAlreadyRegisteredException;
import com.project.feecollection.exceptions.EmptyInputException;
import com.project.feecollection.exceptions.UserDoesNotExistsException;
import com.project.feecollection.model.Accountant;
import com.project.feecollection.repository.AccountantRepository;

import jakarta.transaction.Transactional;

@Service
public class AccountantService {

	private final AccountantRepository accountantRepository;

	@Autowired
	public AccountantService(AccountantRepository accountantRepository) {
		super();
		this.accountantRepository = accountantRepository;
	}

	public List<Accountant> getAllAccountants() {

		return accountantRepository.findAll();
	}

	public Optional<Accountant> getAccountantById(Integer accountantId) {
		// TODO Auto-generated method stub
		return accountantRepository.findById(accountantId);
	}

	public Accountant getAccountantByEmail(String email) {
		// TODO Auto-generated method stub
		return accountantRepository.findAccountantByEmail(email);
	}

	public Accountant getAccountantByPhone(String phoneNo) {
		// TODO Auto-generated method stub
		return accountantRepository.findAccountantByPhoneNo(phoneNo);
	}

	/*
	 * public Accountant getAccountantByfNameAndlName(String fname, String lname) { //
	 * TODO Auto-generated method stub return
	 * accountantRepository.findAccountantByFirstNameAndLastName(fname, lname); }
	 */

	public void addNewAccountant(Accountant accountant) {

		// if the email is already taken , return an exception instead of inserting the
		// accountant in db

		if (accountant != null && accountant.getFirstName() == null || accountant.getFirstName().length() <= 0) {
			throw new EmptyInputException("601", "First Name cannot be empty");
		}

		if (accountantRepository.existsByEmail(accountant.getEmail())) {
			throw new EmailAlreadyRegisteredException("602", "Email is already taken");
		}
		accountantRepository.save(accountant);

	}

	public void deleteAccountant(Integer accountantId) {

		boolean accountantExists = accountantRepository.existsById(accountantId);

		if (accountantExists) {
			accountantRepository.deleteById(accountantId);
		}
		else throw new UserDoesNotExistsException("603", "User that you are trying to delete does not exists");

	}

	@Transactional
	public void updateAccountant(Integer accountantId, String fname, String email) {

		Optional<Accountant> accountantFromDb = accountantRepository.findById(accountantId);

		System.out.println(accountantFromDb.get().getFirstName() + " name from db" + fname);

		if (fname != null && fname.length() > 0 && !fname.equals(accountantFromDb.get().getFirstName())) {
			accountantFromDb.get().setFirstName(fname);
		}

		if (email != null && email.length() > 0 && !(email.equals(accountantFromDb.get().getEmail()))) {

			if (accountantRepository.existsByEmail(email)) {
				throw new EmailAlreadyRegisteredException("602", "Email is already taken");
			}
			accountantFromDb.get().setEmail(email);
		}

	}

}
