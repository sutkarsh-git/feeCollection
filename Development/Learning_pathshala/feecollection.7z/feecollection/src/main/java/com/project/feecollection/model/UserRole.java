package com.project.feecollection.model;

public enum UserRole {
			ADMIN, ACCOUNTANT, STUDENT
}
