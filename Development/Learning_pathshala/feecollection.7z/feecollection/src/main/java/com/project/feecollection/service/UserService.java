package com.project.feecollection.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.feecollection.dto.ChangePasswordDTO;
import com.project.feecollection.exceptions.EmailAlreadyRegisteredException;
import com.project.feecollection.exceptions.EmptyInputException;
import com.project.feecollection.exceptions.IncorrectPasswordExeption;
import com.project.feecollection.exceptions.UserDoesNotExistsException;
import com.project.feecollection.model.Login;
import com.project.feecollection.model.User;
import com.project.feecollection.model.UserRole;
import com.project.feecollection.repository.UserRepository;
import com.project.feecollection.utils.EmailDetails;
import com.project.feecollection.utils.EmailService;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EmailDetails emailDetails;

	@Autowired
	private EmailService emailService;

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	public Optional<User> getUserById(Long userId) {
		// TODO Auto-generated method stub
		return userRepository.findById(userId);
	}

	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByEmail(email);
	}

	public User getUserByPhone(String phoneNo) {
		// TODO Auto-generated method stub
		return userRepository.findUserByPhoneNo(phoneNo);
	}

	/*
	 * public User getUserByfNameAndlName(String fname, String lname) { // TODO
	 * Auto-generated method stub return
	 * userRepository.findUserByFirstNameAndLastName(fname, lname); }
	 */
	public List<User> getAllUsersByUserRole(String userRole) {
		// TODO Auto-generated method stub
		return userRepository.findByUserRole(UserRole.valueOf(userRole));
	}

	public void addNewUser(User user) {
		// TODO Auto-generated method stub

		if (userRepository.existsByEmail(user.getEmail())) {
			throw new EmailAlreadyRegisteredException("601", "Email is already taken");
		}
		userRepository.save(user);

	}

	public void deleteUser(Long userId) {
		// TODO Auto-generated method stub

		boolean userExists = userRepository.existsById(userId);

		if (userExists) {
			userRepository.deleteById(userId);
		} else
			throw new UserDoesNotExistsException("602", "User you are trying to delete does not exists in the db");

	}

	public void updateStudent(Long userId, String name, String email) {
		// TODO Auto-generated method stub

	}

	public void validateUserLogin(Login login) {

		if (login != null && login.getEmail() != null && login.getPassword() != null && login.getUserRole() != null) {

			if (userRepository.existsByEmail(login.getEmail())) {
				// enter here if user exists by email
				if (userRepository.existsByEmailAndPassword(login.getEmail(), login.getPassword())) {
					// enter here if user exists by email and password
					User user = userRepository.findUserByEmailAndPasswordAndUserRole(login.getEmail(),
							login.getPassword(), UserRole.valueOf(login.getUserRole()));

					if (user != null && user.getEmail().length() > 1) {
						System.out.println("User logged in successfully");
						;
					} else
						// no combination of user , password and role exists in the db, throwing an
						// error here .
						throw new UserDoesNotExistsException("602", "The user role selected is incorrect");

				} else
					throw new IncorrectPasswordExeption("604", "Wrong Password");

			} else
				throw new UserDoesNotExistsException("602",
						"Could not find any user with the email " + login.getEmail());

		} else
			throw new EmptyInputException("603", "One or more input/s is empty");

	}

	// forget password methods

	// take the email and token and check if the email exists save the token in the
	// table
	public void updateResetPasswordToken(String token, String email) throws UserDoesNotExistsException {
		User user = userRepository.findByEmail(email);
		System.out.println("printing the user here --------------------" + user);
		if (user != null) {
			user.setResetPasswordToken(token);
			userRepository.save(user);
		} else {
			throw new UserDoesNotExistsException("602", "Could not find any user with the email " + email);
		}
	}

	// find the user by the token when the user clicks on the token
	public User getByResetPasswordToken(String token) {
		return userRepository.findByResetPasswordToken(token);
	}

	// get the new password from the user and save it in the password column in the
	// table
	public void updatePassword(User user, String newPassword) {
		// BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		// String encodedPassword = passwordEncoder.encode(newPassword);
		user.setPassword(newPassword);

		user.setResetPasswordToken(null);
		userRepository.save(user);
	}

	public void sendEmail(String email, String resetPasswordLink) {
		// TODO Auto-generated method stub

		String subject = "Here's the link to reset your password";

		String content = "<p>Hello,</p>" + "<p>You have requested to reset your password.</p>"
				+ "<p>Click the link below to change your password:</p>" + "<p><a href=\"" + resetPasswordLink
				+ "\">Change my password</a></p>" + "<br>" + "<p>Ignore this email if you do remember your password, "
				+ "or you have not made the request.</p>";

		emailDetails.setRecipient(email);
		emailDetails.setSubject(subject);
		emailDetails.setMsgBody(content);

		emailService.sendSimpleMail(emailDetails);
	}

	public User getUserfromUserToken(String token) {
		// TODO Auto-generated method stub
		User user = userRepository.findByResetPasswordToken(token);
		if (user == null) {
			throw new UserDoesNotExistsException("602", "Could not find any user with the token");
		}
		return user;
	}

	public void changePasswordSetTokenNull(ChangePasswordDTO changePasswordDto) {
		// TODO Auto-generated method stub

		// get the User from the token.

		User user = getUserfromUserToken(changePasswordDto.getToken());
		// update the new password in the user object
		if (user != null) {
			user.setPassword(changePasswordDto.getPassword());
			user.setResetPasswordToken(null);
		}

		// save
		userRepository.save(user);

	}

}
