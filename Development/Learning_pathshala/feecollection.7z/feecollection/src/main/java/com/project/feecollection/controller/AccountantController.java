package com.project.feecollection.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.feecollection.model.Accountant;
import com.project.feecollection.service.AccountantService;

@RestController
public class AccountantController {

	private final AccountantService accountantService;

	@Autowired
	public AccountantController(AccountantService accountantService) {
		super();
		this.accountantService = accountantService;
	}

	@GetMapping("/accountants")
	public List<Accountant> getAllAccountants() {
		return accountantService.getAllAccountants();

	}

	@GetMapping("/accountants/{accountantId}")
	public Optional<Accountant> getAccountantById(@PathVariable("accountantId") Integer accountantId) {
		return accountantService.getAccountantById(accountantId);

	}

	@GetMapping("/accountants/email/{email}")
	public Accountant getAccountantByEmail(@PathVariable("email") String email) {
		return accountantService.getAccountantByEmail(email);

	}

	@GetMapping("/accountants/phone/{phoneNo}")
	public Accountant getAccountantByPhone(@PathVariable("phoneNo") String phoneNo) {
		return accountantService.getAccountantByPhone(phoneNo);

	}

	/*
	 * @GetMapping("/accountants/fname/{fname}/lname/{lname}") public Accountant
	 * getAccountantByfNameAndlName(@PathVariable("fname") String
	 * fname, @PathVariable("lname") String lname) { return
	 * accountantService.getAccountantByfNameAndlName(fname, lname);
	 * 
	 * }
	 */

	@PostMapping("/accountants")
	public void createAccountant(@RequestBody Accountant student) {

		accountantService.addNewAccountant(student);

	}

	@DeleteMapping("/accountants/{accountantId}")
	public void deleteAccountant(@PathVariable("accountantId") Integer accountantId) {

		accountantService.deleteAccountant(accountantId);

	}

	@PutMapping("/accountants/{accountantId}")
	public void updateAccountant(@PathVariable("accountantId") Integer accountantId, @RequestParam(required = false) String name,
			@RequestParam(required = false) String email) {

		accountantService.updateAccountant(accountantId, name, email);

	}

}

/*
 * created a student class -model created studentcontroller as API layer and get
 * mapping uri was created. create accountantservice as a service layer (to keep
 * business logic) jpa pending TBD
 * 
 * 
 */
