package com.project.feecollection.configuration;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.project.feecollection.model.Fees;
import com.project.feecollection.model.Student;
import com.project.feecollection.model.User;
import com.project.feecollection.model.UserRole;
import com.project.feecollection.repository.FeesRepository;
import com.project.feecollection.repository.StudentRepository;
import com.project.feecollection.repository.UserRepository;

@Configuration
public class UserConfiguration {
	

	
	@Bean
	CommandLineRunner commandLineRunner0 (UserRepository userRepository) {
		
		return args -> {
			User sheryl = new User("sheryl@gmail.com", "sheryl", "9559617790", UserRole.STUDENT);
			
			User aarna = new User( "aarna@gmail.com", "aarna", "8744047344", UserRole.STUDENT);
			
			User utkarsh = new User("utkarsh.k2@gmail.com", "utkarsh", "3334728887", UserRole.ACCOUNTANT);
			
			User prashansha = new User("prashansha@gmail.com", "prashansha", "3311753480", UserRole.ACCOUNTANT);
			
			User admin = new User("admin@gmail.com", "admin", "9415742651", UserRole.ADMIN);
			
			userRepository.saveAll(List.of(sheryl,aarna, utkarsh, prashansha, admin ));
	};
	
	}
	

	
	@Bean
	CommandLineRunner commandLineRunner (StudentRepository studentRepository) {
		
		return args -> {
			Student sheryl = new Student("Sheryl","Srivastava" ,"sheryl@gmail.com", LocalDate.of(2018, 12, 31),"9415742651",2);
			
			Student aarna = new Student("Aarna" ,"Srivastava", "aarna@gmail.com", LocalDate.of(2020, 01, 30),"9415742652",1);
			
			
			studentRepository.saveAll(List.of(sheryl,aarna));
			
	};
	
	}
	
	@Bean
	CommandLineRunner commandLineRunner1 (FeesRepository feesRepository) {
		
		return args -> {
			Fees fees1 = new Fees(1, 1, 2022, "January", 10000.0, 5000.0);
			
			Fees fees2 = new Fees(1, 1, 2022, "Febuary", 15000.0, 0.0);
			
			Fees fees3 = new Fees(1, 1, 2022, "March", 10000.0, 5000.0);
			
			Fees fees4 = new Fees(2, 2, 2022, "January", 15000.0, 0.0);
			
			Fees fees5 = new Fees(2, 2, 2022, "Febuary", 15000.0, 0.0);
			
			
			feesRepository.saveAll(List.of(fees1,fees2,fees3,fees4,fees5));
			
	};
	
	}



}
