package com.project.feecollection.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Table
@Entity
public class Fees {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private Integer studentId;
	private Integer grade;
	@Column(name ="f_year")
	private Integer year;
	@Column(name ="f_month")
	private String month;
	private double amountPaid;
	private double amountDue;
	
	
	public Fees(Integer studentId, Integer grade, Integer year, String month, double amountPaid, double amountDue) {
		super();
		this.studentId = studentId;
		this.grade = grade;
		this.year = year;
		this.month = month;
		this.amountPaid = amountPaid;
		this.amountDue = amountDue;
	}
	


}
