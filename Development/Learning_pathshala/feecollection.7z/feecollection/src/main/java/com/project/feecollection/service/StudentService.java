package com.project.feecollection.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.feecollection.exceptions.EmailAlreadyRegisteredException;
import com.project.feecollection.exceptions.EmptyInputException;
import com.project.feecollection.model.Student;
import com.project.feecollection.repository.StudentRepository;

import jakarta.transaction.Transactional;

@Service
public class StudentService {

	private final StudentRepository studentRepository;

	@Autowired
	public StudentService(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	public List<Student> getAllStudents() {

		return studentRepository.findAll();
	}

	public Optional<Student> getStudentById(Integer studentId) {
		// TODO Auto-generated method stub
		return studentRepository.findById(studentId);
	}

	public Student getStudentByEmail(String email) {
		// TODO Auto-generated method stub
		return studentRepository.findStudentByEmail(email);
	}

	public Student getStudentByPhone(String phoneNo) {
		// TODO Auto-generated method stub
		return studentRepository.findStudentByPhoneNo(phoneNo);
	}

	/*
	 * public Student getStudentByfNameAndlName(String fname, String lname) { //
	 * TODO Auto-generated method stub return
	 * studentRepository.findStudentByFirstNameAndLastName(fname, lname); }
	 */
	public List<Student> getAllStudentsByGrade(Integer grade) {
		// TODO Auto-generated method stub
		return studentRepository.findStudentByGrade(grade);
	}

	public void addNewStudent(Student student) {

		// if the email is already taken , return an exception instead of inserting the
		// student in db

		if (student != null && student.getFirstName() == null || student.getFirstName().length() <= 0) {
			throw new EmptyInputException("601", "First Name cannot be empty");
		}

		if (studentRepository.existsByEmail(student.getEmail())) {
			throw new EmailAlreadyRegisteredException("602", "Email is already taken");
		}
		studentRepository.save(student);

	}

	public void deleteStudent(Integer studentId) {

		boolean studentExists = studentRepository.existsById(studentId);

		if (studentExists) {
			studentRepository.deleteById(studentId);
		}

	}

	@Transactional
	public void updateStudent(Integer studentId, String fname, String email) {

		Optional<Student> studentFromDb = studentRepository.findById(studentId);

		System.out.println(studentFromDb.get().getFirstName() + " name from db" + fname);

		if (fname != null && fname.length() > 0 && !fname.equals(studentFromDb.get().getFirstName())) {
			studentFromDb.get().setFirstName(fname);
		}

		if (email != null && email.length() > 0 && !(email.equals(studentFromDb.get().getEmail()))) {

			if (studentRepository.existsByEmail(email)) {
				throw new EmailAlreadyRegisteredException("602", "Email is already taken");
			}
			studentFromDb.get().setEmail(email);
		}

	}

}
