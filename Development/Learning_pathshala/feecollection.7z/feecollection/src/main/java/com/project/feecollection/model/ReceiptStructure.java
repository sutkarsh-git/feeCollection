package com.project.feecollection.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReceiptStructure {

	private String recieptNo;
	private double baseFee;
	private double tutuinFee;
	private double busFee;
	private double examFee;
	private double latePaymentFee;
	private String paymentMethod;
	private String schoolName;
	private String schoolAddress;
	private String schoolPhoneNo;

	public ReceiptStructure(String recieptNo, double baseFee, double tutuinFee, double busFee, double examFee,
			double latePaymentFee, String paymentMethod, String schoolName, String schoolAddress,
			String schoolPhoneNo) {
		super();
		this.recieptNo = recieptNo;
		this.baseFee = baseFee;
		this.tutuinFee = tutuinFee;
		this.busFee = busFee;
		this.examFee = examFee;
		this.latePaymentFee = latePaymentFee;
		this.paymentMethod = paymentMethod;
		this.schoolName = schoolName;
		this.schoolAddress = schoolAddress;
		this.schoolPhoneNo = schoolPhoneNo;
	}

}
