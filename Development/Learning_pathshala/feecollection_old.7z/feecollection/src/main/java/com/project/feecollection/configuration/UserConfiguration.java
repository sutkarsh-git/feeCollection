package com.project.feecollection.configuration;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.project.feecollection.model.User;
import com.project.feecollection.model.UserRole;
import com.project.feecollection.repository.UserRepository;

@Configuration
public class UserConfiguration {
	

	
	@Bean
	CommandLineRunner commandLineRunner (UserRepository userRepository) {
		
		return args -> {
			User sheryl = new User("Sheryl", "Srivastava", "sheryl@gmail.com", "sheryl", "9559617790", UserRole.ADMIN);
			
			User aarna = new User("Aarna", "Srivastava", "aarna@gmail.com", "aarna", "8744047344", UserRole.ADMIN);
			
			User utkarsh = new User("Utkarsh", "Srivastava", "utkarsh@gmail.com", "utkarsh", "3334728887", UserRole.CASHIER);
			
			User prashansha = new User("Prashansha", "Srivastava", "prashansha@gmail.com", "prashansha", "3311753480", UserRole.CASHIER);
			
			userRepository.saveAll(List.of(sheryl,aarna, utkarsh, prashansha ));
	};
	
	}

}
