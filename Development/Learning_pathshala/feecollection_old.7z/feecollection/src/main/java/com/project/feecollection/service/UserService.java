package com.project.feecollection.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.feecollection.exceptions.EmailAlreadyRegisteredException;
import com.project.feecollection.exceptions.UserDoesNotExistsException;
import com.project.feecollection.model.User;
import com.project.feecollection.model.UserRole;
import com.project.feecollection.repository.UserRepository;

@Service
public class UserService {

	private final UserRepository userRepository;

	@Autowired
	public UserService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	public Optional<User> getUserById(Long userId) {
		// TODO Auto-generated method stub
		return userRepository.findById(userId);
	}

	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.findUserByEmail(email);
	}

	public User getUserByPhone(String phoneNo) {
		// TODO Auto-generated method stub
		return userRepository.findUserByPhoneNo(phoneNo);
	}

	public User getUserByfNameAndlName(String fname, String lname) {
		// TODO Auto-generated method stub
		return userRepository.findUserByFirstNameAndLastName(fname, lname);
	}

	public List<User> getAllUsersByUserRole(String userRole) {
		// TODO Auto-generated method stub
		return userRepository.findByUserRole(UserRole.valueOf(userRole));
	}

	public void addNewUser(User user) {
		// TODO Auto-generated method stub

		if (userRepository.existsByEmail(user.getEmail())) {
			throw new EmailAlreadyRegisteredException("601", "Email is already taken");
		}
		userRepository.save(user);

	}

	public void deleteUser(Long userId) {
		// TODO Auto-generated method stub

		boolean userExists = userRepository.existsById(userId);

		if (userExists) {
			userRepository.deleteById(userId);
		} else
			throw new UserDoesNotExistsException("602", "User you are trying to delete does not exists in the db");

	}

	public void updateStudent(Long userId, String name, String email) {
		// TODO Auto-generated method stub

	}
//forget password methods	

	// take the email and token and check if the email exists save the token in the
	// table
	public void updateResetPasswordToken(String token, String email) throws UserDoesNotExistsException {
		User user = userRepository.findUserByEmail(email);
		if (user != null) {
			user.setResetPasswordToken(token);
			userRepository.save(user);
		} else {
			throw new UserDoesNotExistsException("602", "Could not find any user with the email " + email);
		}
	}

	// find the user by the token when the user clicks on the token
	public User getByResetPasswordToken(String token) {
		return userRepository.findByResetPasswordToken(token);
	}

	// get the new password from the user and save it in the password column in the
	// table
	public void updatePassword(User user, String newPassword) {
		// BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		// String encodedPassword = passwordEncoder.encode(newPassword);
		user.setPassword(newPassword);

		user.setResetPasswordToken(null);
		userRepository.save(user);
	}

}
