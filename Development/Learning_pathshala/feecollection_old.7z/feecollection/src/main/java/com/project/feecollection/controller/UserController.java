package com.project.feecollection.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.feecollection.model.User;
import com.project.feecollection.service.UserService;

@RestController
public class UserController {

	private final UserService userService;

	@Autowired
	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	@GetMapping("/users")
	public List<User> getAllUsers() {
		return userService.getAllUsers();

	}

	@GetMapping("/users/{userId}")
	public Optional<User> getUserById(@PathVariable("userId") Long userId) {
		return userService.getUserById(userId);

	}

	@GetMapping("/users/email/{email}")
	public User getUserByEmail(@PathVariable("email") String email) {
		return userService.getUserByEmail(email);

	}

	@GetMapping("/users/phone/{phoneNo}")
	public User getUserByPhone(@PathVariable("phoneNo") String phoneNo) {
		return userService.getUserByPhone(phoneNo);

	}
	
	@GetMapping("/users/fname/{fname}/lname/{lname}")
	public User getUserByfNameAndlName(@PathVariable("fname") String fname , @PathVariable("lname") String lname) {
		return userService.getUserByfNameAndlName(fname, lname);

	}
	
	@GetMapping("/users/userrole/{userrole}")
	public List<User> getAllUsersByUserRole(@PathVariable("userrole") String userrole ) {
		return userService.getAllUsersByUserRole(userrole);

	}


	@PostMapping("/users")
	public void createUser(@RequestBody User user) {

		userService.addNewUser(user);

	}

	@DeleteMapping("/users/{userId}")
	public void deleteUser(@PathVariable("userId") Long userId) {

		userService.deleteUser(userId);

	}

	@PutMapping("/users/{userId}")
	public void updateStudent(@PathVariable("userId") Long userId, @RequestParam(required = false) String name,
			@RequestParam(required = false) String email) {

		userService.updateStudent(userId, name, email);

	}

}
