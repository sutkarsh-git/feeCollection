package com.project.feecollection.globalexceptions;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.project.feecollection.exceptions.EmailAlreadyRegisteredException;
import com.project.feecollection.exceptions.EmptyInputException;
import com.project.feecollection.exceptions.UserDoesNotExistsException;

@ControllerAdvice
public class GlobalExceptionHandling {
	
	@ExceptionHandler(EmptyInputException.class)
	public ResponseEntity<String> handleEmptyInput(EmptyInputException emptyInputException){
		
		return new ResponseEntity<String>("input is empty", HttpStatus.BAD_REQUEST);		
	}
	
	@ExceptionHandler(EmailAlreadyRegisteredException.class)
	public ResponseEntity<String> handleEmptyDaoException(EmailAlreadyRegisteredException emailAlreadyRegisteredException){
		
		return new ResponseEntity<String>("Email u r using is already registered", HttpStatus.ALREADY_REPORTED);		
	}
	
	@ExceptionHandler(UserDoesNotExistsException.class)
	public ResponseEntity<String> handleEmptyDaoException(UserDoesNotExistsException userDoesNotExistsException){
		
		return new ResponseEntity<String>("User does not exists exception", HttpStatus.NOT_FOUND);		
	}
	
	@ExceptionHandler(EmptyResultDataAccessException.class)
	public ResponseEntity<String> handleEmptyDaoException(EmptyResultDataAccessException emptyResultDataAccessException){
		
		return new ResponseEntity<String>("Resource doesn't exists in the db", HttpStatus.NOT_FOUND);		
	}

}
